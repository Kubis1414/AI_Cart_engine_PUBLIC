"""
AIbrain_TymE - Neuronová síť pro řízení autíčka
Tým E - 4IT534

Architektura: Jednoduchý MLP
- Vstup: 9 raycast paprsků (vzdálenosti v dlaždicích, max ~15)
- Skrytá vrstva: 8 neuronů
- Výstup: 4 akce (plyn, brzda, doleva, doprava)
"""

from numpy import random as np_random
import random
import numpy as np
import copy
import string

# Architektura sítě
N_INPUTS = 9       # 9 raycast paprsků (bez rychlosti - zbytečně to komplikuje)
N_HIDDEN = 8       # Jedna skrytá vrstva
N_ACTIONS = 4      # [up, down, left, right]

MAX_RAY_DISTANCE = 15.0

# Mutace
MUTATION_RATE = 0.15


class AIbrain_TymE:
    def __init__(self):
        super().__init__()
        self.score = 0
        self.chars = string.ascii_letters + string.digits
        self.decider = 0
        
        # Data z auta
        self.x = 0
        self.y = 0
        self.speed = 0
        
        self.init_param()

    def init_param(self):
        """
        HEURISTICKÁ inicializace - dáme autům základní "instinkty":
        - Jet dopředu když je volno
        - Zatočit směrem kde je více místa
        
        Raycast indexy: [-90°, -45°, -20°, -5°, 0°, 5°, 20°, 45°, 90°]
                         0     1     2     3    4   5    6     7    8
                        <-- LEVÁ STRANA -->  ^  <-- PRAVÁ STRANA -->
        """
        # Vrstva 1 - náhodná s malými hodnotami
        self.W1 = np_random.randn(N_HIDDEN, N_INPUTS) * 0.3
        self.b1 = np.zeros(N_HIDDEN)
        
        # Výstupní vrstva - HEURISTICKÁ inicializace
        self.W2 = np_random.randn(N_ACTIONS, N_HIDDEN) * 0.3
        
        # Bias nastavíme chytře:
        # [plyn, brzda, left, right]
        self.b2 = np.array([1.2, -1.5, -1.5, -1.5])  # zatáčení defaultně víc OFF
        
        # KLADNÁ váha + vysoký vstup = aktivace
        self.W_direct = np.zeros((N_ACTIONS, N_INPUTS))
        
        # rays 0,1,2,3 jsou levá strana -> KLADNÉ váhy pro RIGHT (index 3)
        self.W_direct[3, 0] = 0.5   # -90° vlevo -> right+
        self.W_direct[3, 1] = 0.8   # -45° vlevo -> right++
        self.W_direct[3, 2] = 1.0   # -20° vlevo -> right+++
        self.W_direct[3, 3] = 0.6   # -5° vlevo -> right+
        
        self.W_direct[2, 8] = 0.5   # 90° vpravo -> left+
        self.W_direct[2, 7] = 0.8   # 45° vpravo -> left++
        self.W_direct[2, 6] = 1.0   # 20° vpravo -> left+++
        self.W_direct[2, 5] = 0.6   # 5° vpravo -> left+
        
        self.W_direct[1, 4] = 1.0   # 0° vpředu blízko -> brzda+
        
        self.W_direct[0, 4] = -0.3  # 0° vpředu blízko -> méně plynu
        
        self.NAME = "TymE_" + ''.join(random.choices(self.chars, k=4))
        self.store()

    def _relu(self, x):
        return np.maximum(0, x)

    def _sigmoid(self, x):
        """Sigmoid - výstup vždy mezi 0 a 1"""
        x = np.clip(x, -10, 10)  # prevence overflow
        return 1.0 / (1.0 + np.exp(-x))

    def decide(self, data):
        """
        Forward pass - kombinace neuronky + přímých reflexů.
        """
        self.decider += 1
        
        # Vstup: raycast vzdálenosti (v dlaždicích)
        x = np.asarray(data, dtype=float).ravel()
        
        # Zajistit správnou délku
        if x.size < N_INPUTS:
            x = np.concatenate([x, np.zeros(N_INPUTS - x.size)])
        elif x.size > N_INPUTS:
            x = x[:N_INPUTS]
        
        # Normalizace do [0, 1]
        x_norm = x / MAX_RAY_DISTANCE
        x_norm = np.clip(x_norm, 0, 1)
        
        z1 = self.W1.dot(x_norm) + self.b1
        a1 = self._relu(z1)
        nn_output = self.W2.dot(a1)
        
        # === 2. Přímé reflexy (základní instinkty) ===
        x_inv = 1.0 - x_norm  # blízko = vysoká hodnota
        direct_output = self.W_direct.dot(x_inv)
        
        # === 3. Kombinace + bias ===
        combined = nn_output + direct_output + self.b2
        output = self._sigmoid(combined)
        
        return output

    def mutate(self):
        """
        Mutace - VŽDY změň všechny váhy trochu.
        """
        # Malý šum ke všem vahám
        self.W1 += np_random.randn(*self.W1.shape) * MUTATION_RATE
        self.b1 += np_random.randn(*self.b1.shape) * MUTATION_RATE
        self.W2 += np_random.randn(*self.W2.shape) * MUTATION_RATE
        self.b2 += np_random.randn(*self.b2.shape) * MUTATION_RATE
        self.W_direct += np_random.randn(*self.W_direct.shape) * MUTATION_RATE * 0.5
        
        # Občasná velká mutace (5% šance)
        if np_random.rand() < 0.05:
            i = np_random.randint(0, N_HIDDEN)
            j = np_random.randint(0, N_INPUTS)
            self.W1[i, j] += np_random.randn() * 0.5

        self.NAME += "m"
        self.store()

    def store(self):
        self.parameters = copy.deepcopy({
            'W1': self.W1, 'b1': self.b1,
            'W2': self.W2, 'b2': self.b2,
            'W_direct': self.W_direct,
            'NAME': self.NAME,
        })

    def get_parameters(self):
        return copy.deepcopy(self.parameters)

    def set_parameters(self, parameters):
        if isinstance(parameters, np.lib.npyio.NpzFile):
            p = {key: parameters[key] for key in parameters.files}
        else:
            p = copy.deepcopy(parameters)
        
        self.parameters = p
        self.W1 = np.array(p['W1'], dtype=float)
        self.b1 = np.array(p['b1'], dtype=float)
        self.W2 = np.array(p['W2'], dtype=float)
        self.b2 = np.array(p['b2'], dtype=float)
        
        # Zpětná kompatibilita - pokud W_direct není v uloženém souboru
        if 'W_direct' in p:
            self.W_direct = np.array(p['W_direct'], dtype=float)
        else:
            self.W_direct = np.zeros((N_ACTIONS, N_INPUTS))
            
        self.NAME = str(p['NAME'])

    def calculate_score(self, distance, time, no):
        """Skóre = ujetá vzdálenost. Jednoduché a funkční."""
        self.score = distance

    def passcardata(self, x, y, speed):
        self.x = x
        self.y = y
        self.speed = speed

    def getscore(self):
        return self.score
